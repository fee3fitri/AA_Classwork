# ----- matrix_addition_reloaded -----
# Write a method squarocol? that accepts a 2-dimensional array as an argument. 
# The method should return a boolean indicating whether or not any row or column is 
# completely filled with the same element. 
# You may assume that the 2-dimensional array has "square" dimensions, 
# meaning it's height is the same as it's width.

def squarocol?(arr)
    flat = arr.flatten
    len = arr.length
    flat.each_with_index do |el, i|
      if flat.count(el) == arr.length && ((el == flat[i + len] && el == flat[i + 2 * len]) || (el == flat[i + 1] && el == flat[i + 2]))
        return true
      end
    end
    return false
  end
  
  p squarocol?([
      [:a, :x , :d],
      [:b, :x , :e],
      [:c, :x , :f],
  ]) # true
  
  p squarocol?([
      [:x, :y, :x],
      [:x, :z, :x],
      [:o, :o, :o],
  ]) # true
  
  p squarocol?([
      [:o, :x , :o],
      [:x, :o , :x],
      [:o, :x , :o],
  ]) # false
  
  p squarocol?([
      [1, 2, 2, 7],
      [1, 6, 6, 7],
      [0, 5, 2, 7],
      [4, 2, 9, 7],
  ]) # true
  
  p squarocol?([
      [1, 2, 2, 7],
      [1, 6, 6, 0],
      [0, 5, 2, 7],
      [4, 2, 9, 7],
  ]) # false


  def triangle_num(num)
    arr = []
    
    if num == 1
        arr = [[1]]
    elsif num <= 2
        arr = [[1], [1, 1]]
    end

    while arr.length < num
        previous = arr[-1]
        next = [1]
        triangle(previous)
    end
  end

  def triangle(arr)
    new_arr = []
    (0...arr.length - 1).each_with_index do |el, i|
        new_arr << el + arr[i + 1]
    end
    new_arr
  end

  p pascals_triangle(5)
# [
#     [1],
#     [1, 1],
#     [1, 2, 1],
#     [1, 3, 3, 1],
#     [1, 4, 6, 4, 1]
# ]

p pascals_triangle(7)
# [
#     [1],
#     [1, 1],
#     [1, 2, 1],
#     [1, 3, 3, 1],
#     [1, 4, 6, 4, 1],
#     [1, 5, 10, 10, 5, 1],
#     [1, 6, 15, 20, 15, 6, 1]
# ]